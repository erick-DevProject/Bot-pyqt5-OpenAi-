from PyQt5.QtWidgets import QMainWindow
from views.ui.ChatUi import Ui_InterfaceChat
from PyQt5 import QtCore, QtGui, QtWidgets
# QSpacerItem
from PyQt5.QtWidgets import QSpacerItem

class ChatView(QMainWindow, Ui_InterfaceChat):
    # customLoadFinished = pyqtSignal(bool)
    def __init__(self, controller):
        super(ChatView, self).__init__()
        self.setupUi(self)
        self.controller = controller

        self.hide()
        self.labelGenerateResponse.hide()
        self.deleteAllWidgetsMessage()

        self.ButtonNewChat.clicked.connect(lambda: self.controller.onNewChat())

    def addMessage(self, message_text, is_assistant=False):
        # creamos un widget
        self.widget = QtWidgets.QWidget(self.scrollAreaWidgetContentsMessages)
        self.widget.setObjectName("widget_4s")
        self.horizontalLayout_5 = QtWidgets.QHBoxLayout(self.widget)
        self.horizontalLayout_5.setObjectName("horizontalLayout_5")

        if is_assistant:
            self.label = QtWidgets.QLabel(self.widget)
            self.label.setMinimumSize(QtCore.QSize(36, 36))
            self.label.setMaximumSize(QtCore.QSize(36, 36))
            self.label.setText("")
            self.label.setPixmap(QtGui.QPixmap(":/icons/RiRobot2Fill.png"))
            self.label.setScaledContents(True)
            self.label.setIndent(0)
            self.label.setObjectName("labeldddd")
            self.horizontalLayout_5.addWidget(self.label)
        else:
            self.label = QtWidgets.QLabel(self.widget)
            self.label.setMinimumSize(QtCore.QSize(36, 36))
            self.label.setMaximumSize(QtCore.QSize(36, 36))
            self.label.setText("")
            self.label.setPixmap(QtGui.QPixmap(":/icons/SolarUserCircleBold.png"))
            self.label.setScaledContents(True)
            self.label.setIndent(0)
            self.label.setObjectName("labeldddd")
            self.horizontalLayout_5.addWidget(self.label)

        self.widget_9 = QtWidgets.QWidget(self.widget)
        self.widget_9.setObjectName("widget_9")
        self.horizontalLayout_6 = QtWidgets.QHBoxLayout(self.widget_9)
        self.horizontalLayout_6.setObjectName("horizontalLayout_6")

        self.label_3 = QtWidgets.QLabel(self.widget_9)
        font = QtGui.QFont()
        font.setBold(False)
        font.setItalic(False)
        font.setUnderline(False)
        font.setWeight(50)
        self.label_3.setFont(font)
        self.label_3.setStyleSheet("QLabel{\n    color: rgb(193, 193, 193)\n}")
        self.label_3.setScaledContents(True)
        self.label_3.setWordWrap(True)
        self.label_3.setIndent(0)
        self.label_3.setTextInteractionFlags(QtCore.Qt.NoTextInteraction)
        self.label_3.setObjectName("label_3")
        self.label_3.setText(message_text)
        self.horizontalLayout_6.addWidget(self.label_3)
        self.horizontalLayout_5.addWidget(self.widget_9)

        self.verticalLayout_6.addWidget(self.widget)

    def deleteAllWidgetsMessage(self):
        layout = self.scrollAreaWidgetContentsMessages.layout()
        if layout:
            for i in reversed(range(layout.count())):  # Recorremos en reversa para evitar problemas de índices
                widget_item = layout.itemAt(i)
                if widget_item is not None:
                    widget = widget_item.widget()
                    if widget is not None and not isinstance(widget, QSpacerItem):
                        widget.deleteLater()