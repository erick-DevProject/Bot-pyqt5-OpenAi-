from views.ChatView import ChatView
from models.OpenAIGenerator import OpenAIGenerator
from PyQt5.QtCore import QThread, pyqtSignal
from PyQt5.QtWidgets import QMessageBox

# Hilos de ejecución
class WorkerThread(QThread):
    result = pyqtSignal(str)

    def __init__(self, generator, prompt):
        super().__init__()
        self.generator = generator
        self.prompt = prompt

    def run(self):
        completion = self.generator.generate_completion(self.prompt)
        self.result.emit(completion)

class MainController:
    def __init__(self, app):
        self.app = app
        self.Mainview = ChatView(self)
        # Configurar API key
        api_key = "YOUR_API_KEY"
        self.AiGenerator = OpenAIGenerator(api_key=api_key)
        self.history_messages = []
        self.Mainview.show()

        self.Mainview.createCompletion.clicked.connect(self.handle_create_completion)
        self.worker = None

    def handle_create_completion(self):
        prompt = self.Mainview.enterMessage.text()
        if not prompt:
            self.Mainview.createCompletion.setEnabled(True)
            return

        self.Mainview.createCompletion.setEnabled(False)
        # Limpiamos el input
        self.Mainview.enterMessage.setText("")
        self.Mainview.addMessage(prompt, is_assistant=False)
        self.Mainview.labelGenerateResponse.show()

        self.worker = WorkerThread(self.AiGenerator, prompt)
        self.worker.result.connect(self.on_completion_result)
        self.worker.start()
    
    def show_error_dialog(self, error_message):
        error_dialog = QMessageBox(self.Mainview)  # Pasar self.Mainview como el padre
        error_dialog.setIcon(QMessageBox.Critical)
        error_dialog.setWindowTitle("Error")
        error_dialog.setText("Error")
        error_dialog.setInformativeText(error_message)
        error_dialog.setStandardButtons(QMessageBox.Ok)
        error_dialog.exec_()

    # Recibe el resultado del hilo de ejecución
    def on_completion_result(self, result):
        self.Mainview.labelGenerateResponse.hide()
        self.Mainview.createCompletion.setEnabled(True)
        self.Mainview.enterMessage.setFocus()

        # Si ha ocurrido un error mostramos una alerta de error
        if not result:
            self.show_error_dialog("Ha ocurrido un error al conectar a la API")
            return

        self.AiGenerator.set_asistant_history(result)
        self.Mainview.addMessage(result, is_assistant=True)
        self.worker.quit()
        self.worker.wait()

    def onNewChat(self):
        self.Mainview.deleteAllWidgetsMessage()
        self.Mainview.labelGenerateResponse.hide()
        self.history_messages = []
