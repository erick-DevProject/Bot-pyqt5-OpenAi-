import openai

class OpenAIGenerator:
    def __init__(self, api_key):
        self.api_key = api_key
        self.engine = "gpt-4o"
        self.promt_system = "Eres un asistente virtual, tu nombre es ChatCrafter. se divertido y usa emojis. siempre responde de manera educada y amigable."
        self.max_tokens = 800
        openai.api_key = self.api_key

        self.history_messages = []

    def set_engine(self, engine):
        self.engine = engine

    def set_max_tokens(self, max_tokens):
        self.max_tokens = max_tokens

    def set_asistant_history(self, prompt):
        self.history_messages.append(
            {
                "role": "assistant",
                "content": [
                    {
                        "type": "text",
                        "text": prompt
                    }
                ]
            }
        )
    
    def generate_completion(self, prompt):

        System_prompt = [{
            "role": "system",
            "content": [
                {
                    "type": "text",
                    "text": self.promt_system
                }
            ]
        }]

        self.history_messages.append (
            {
                "role": "user",
                "content": [
                    {
                        "type": "text",
                        "text": prompt
                    }
                ]
            }
        )

        messages = System_prompt+ self.history_messages

        try:
            response = openai.chat.completions.create(
                model=self.engine,
                messages=messages,
                temperature=1,
                max_tokens=self.max_tokens,
                top_p=1,
                frequency_penalty=0,
                presence_penalty=0
            ).choices[0].message.content
        except Exception as e:
            print(e)
            response = None

        return response
        